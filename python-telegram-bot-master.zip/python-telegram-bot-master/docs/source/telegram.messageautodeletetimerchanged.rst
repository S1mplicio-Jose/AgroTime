MessageAutoDeleteTimerChanged
=============================

.. autoclass:: telegram.MessageAutoDeleteTimerChanged
    :members:
    :show-inheritance:
