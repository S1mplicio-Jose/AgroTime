MessageReactionUpdated
======================

.. autoclass:: telegram.MessageReactionUpdated
    :members:
    :show-inheritance:
