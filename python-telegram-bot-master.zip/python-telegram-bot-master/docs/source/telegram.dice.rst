Dice
====

.. autoclass:: telegram.Dice
    :members:
    :show-inheritance:
