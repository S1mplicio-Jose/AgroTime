LabeledPrice
============

.. autoclass:: telegram.LabeledPrice
    :members:
    :show-inheritance:
