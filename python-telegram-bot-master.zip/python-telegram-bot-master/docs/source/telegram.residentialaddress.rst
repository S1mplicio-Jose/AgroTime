ResidentialAddress
==================

.. autoclass:: telegram.ResidentialAddress
    :members:
    :show-inheritance:
