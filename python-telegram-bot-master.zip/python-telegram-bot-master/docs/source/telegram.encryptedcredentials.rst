EncryptedCredentials
====================

.. autoclass:: telegram.EncryptedCredentials
    :members:
    :show-inheritance:
