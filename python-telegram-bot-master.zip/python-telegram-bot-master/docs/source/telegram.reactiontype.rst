ReactionType
============

.. autoclass:: telegram.ReactionType
    :members:
    :show-inheritance:
