ReactionTypeEmoji
=================

.. autoclass:: telegram.ReactionTypeEmoji
    :members:
    :show-inheritance:
