AIORateLimiter
==============

.. autoclass:: telegram.ext.AIORateLimiter
    :members:
    :show-inheritance:
