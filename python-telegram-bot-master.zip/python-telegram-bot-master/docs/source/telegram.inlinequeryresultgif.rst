InlineQueryResultGif
====================

.. autoclass:: telegram.InlineQueryResultGif
    :members:
    :show-inheritance:
