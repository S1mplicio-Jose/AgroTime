BackgroundFill
==============

.. versionadded:: 21.2

.. autoclass:: telegram.BackgroundFill
    :members:
    :show-inheritance: