Stickers
--------

The following methods and objects allow your bot to handle stickers and sticker sets.

.. toctree::
    :titlesonly:

    telegram.maskposition
    telegram.sticker
    telegram.stickerset
