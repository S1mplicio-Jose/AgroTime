ReactionCount
=============

.. autoclass:: telegram.ReactionCount
    :members:
    :show-inheritance:
