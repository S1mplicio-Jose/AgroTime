MaybeInaccessibleMessage
========================

.. autoclass:: telegram.MaybeInaccessibleMessage
    :members:
    :show-inheritance:
