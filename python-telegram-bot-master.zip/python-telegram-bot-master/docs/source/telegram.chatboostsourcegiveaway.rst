ChatBoostSourceGiveaway
=======================

.. versionadded:: 20.8

.. autoclass:: telegram.ChatBoostSourceGiveaway
    :members:
    :show-inheritance: