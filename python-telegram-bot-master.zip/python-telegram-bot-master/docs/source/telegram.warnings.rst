telegram.warnings Module
========================

.. automodule:: telegram.warnings
    :members:
    :show-inheritance:
