BusinessConnection
==================

.. autoclass:: telegram.BusinessConnection
    :members:
    :show-inheritance: