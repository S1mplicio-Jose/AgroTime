PaidMediaPurchasedHandler
=========================

.. autoclass:: telegram.ext.PaidMediaPurchasedHandler
    :members:
    :show-inheritance:
