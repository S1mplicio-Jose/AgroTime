TransactionPartner
==================

.. autoclass:: telegram.TransactionPartner
    :members:
    :show-inheritance:
    :inherited-members: TelegramObject
