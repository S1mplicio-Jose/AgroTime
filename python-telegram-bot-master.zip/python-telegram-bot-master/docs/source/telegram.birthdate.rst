Birthdate
=========

.. autoclass:: telegram.Birthdate
    :members:
    :show-inheritance:

