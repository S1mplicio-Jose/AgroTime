ChatMemberRestricted
====================

.. autoclass:: telegram.ChatMemberRestricted
    :members:
    :show-inheritance:
