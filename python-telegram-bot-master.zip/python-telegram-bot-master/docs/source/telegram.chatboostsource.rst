ChatBoostSource
===============

.. versionadded:: 20.8

.. autoclass:: telegram.ChatBoostSource
    :members:
    :show-inheritance: