MessageReactionHandler
======================

.. autoclass:: telegram.ext.MessageReactionHandler
    :members:
    :show-inheritance:
