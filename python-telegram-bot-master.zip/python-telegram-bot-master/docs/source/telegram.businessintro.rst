BusinessIntro
==================

.. autoclass:: telegram.BusinessIntro
    :members:
    :show-inheritance: