BusinessOpeningHours
====================

.. autoclass:: telegram.BusinessOpeningHours
    :members:
    :show-inheritance: