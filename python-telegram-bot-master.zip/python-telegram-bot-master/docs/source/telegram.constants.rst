telegram.constants Module
=========================

.. automodule:: telegram.constants
    :members:
    :show-inheritance:
    :no-undoc-members:
    :inherited-members: Enum, EnumMeta, str, int
    :exclude-members: __format__, __new__, __repr__, __str__
