CallbackDataCache
=================

.. autoclass:: telegram.ext.CallbackDataCache
    :members:
    :show-inheritance:
