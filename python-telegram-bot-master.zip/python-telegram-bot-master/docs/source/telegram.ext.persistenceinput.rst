PersistenceInput
================

.. autoclass:: telegram.ext.PersistenceInput
    :show-inheritance:
